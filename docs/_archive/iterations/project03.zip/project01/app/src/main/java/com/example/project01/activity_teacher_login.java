package com.example.project01;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.widget.LinearLayout;

public class activity_teacher_login extends AppCompatActivity {

    private Button btnLogin;
    private Button btnSign;



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_login);

        btnLogin = findViewById(R.id.btnLogin);
        btnSign = findViewById(R.id.btnSign);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_teacher_login.this, activity_driver_main.class);
                startActivity(intent);
            }
        });

        // 회원가입 버튼 클릭 리스너 설정
        btnSign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_teacher_login.this, activity_teacher_join.class);
                startActivity(intent);
            }
        });
    }
}